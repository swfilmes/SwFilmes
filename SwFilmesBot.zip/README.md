# SwFilmesBot

Um bot do Telegram que envia automaticamente recomendações de filmes e séries todos os dias às 07h e 20h.

## Como usar

1. Configure as variáveis de ambiente:
- `BOT_TOKEN`: Token do seu bot do Telegram
- `GROUP_ID`: ID do grupo para onde o bot vai enviar mensagens

2. Suba no Render ou outro serviço de hospedagem.

3. Pronto! O bot envia postagens automaticamente.